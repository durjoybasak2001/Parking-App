# Parking App

Front-end starter project for a Parking App.

## Files

- `index.html` - main page
- `css/style.css` - design and responsive layout
- `js/script.js` - search and reservation interactions

## Figma Design

https://www.figma.com/design/8UOPNHvV64xtDhKnkTqhRw/Parking-App-Design?node-id=201-1100&t=mOZ4oSFuCJgwbjjT-1

## Run

Open `index.html` in a browser.

## GitHub

Create a repository named `Parking-App`, upload all files, and commit the changes.
