function reserve(location) {
  alert("Reservation request submitted for " + location + ".");
}

function searchParking() {
  const query = document.getElementById("search").value.toLowerCase().trim();
  const cards = document.querySelectorAll(".parking-card");

  cards.forEach(card => {
    const name = card.querySelector("h3").textContent.toLowerCase();
    card.style.display = !query || name.includes(query) ? "block" : "none";
  });
}
